package com.floatbrowser.pip;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 1001;
    private static final int REQ_NOTIF = 1002;

    private TextView statusView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTaskDescription(new ActivityManager.TaskDescription(
                getString(R.string.app_name),
                BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#F5F6FA"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("PIP Float Browser");
        title.setTextSize(24);
        title.setTextColor(Color.parseColor("#1F2430"));
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Browser jendela melayang yang bisa dipakai di atas aplikasi lain. "
                + "Begitu izin diberikan, browser langsung terbuka sebagai jendela melayang "
                + "di Beranda \u2014 tanpa perlu mengetik alamat apa pun.");
        subtitle.setTextSize(13);
        subtitle.setTextColor(Color.parseColor("#555B6E"));
        subtitle.setPadding(0, dp(8), 0, dp(16));
        root.addView(subtitle);

        statusView = new TextView(this);
        statusView.setTextSize(14);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.addView(statusView);

        Button btnOverlay = new Button(this);
        btnOverlay.setText("1. Beri Izin \"Tampil di Atas Aplikasi Lain\"");
        btnOverlay.setAllCaps(false);
        btnOverlay.setOnClickListener(v -> requestOverlayPermission());
        root.addView(btnOverlay);

        Button btnNotif = new Button(this);
        btnNotif.setText("2. Beri Izin Notifikasi (Android 13+)");
        btnNotif.setAllCaps(false);
        btnNotif.setOnClickListener(v -> requestNotifPermission());
        root.addView(btnNotif);

        Button btnStart = new Button(this);
        btnStart.setText("3. Buka Floating Browser (Beranda)");
        btnStart.setAllCaps(false);
        LinearLayout.LayoutParams startLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        startLp.topMargin = dp(18);
        startLp.bottomMargin = dp(6);
        root.addView(btnStart, startLp);
        btnStart.setOnClickListener(v -> launchPip());

        Button btnStop = new Button(this);
        btnStop.setText("Tutup Floating Browser");
        btnStop.setAllCaps(false);
        btnStop.setOnClickListener(v -> {
            stopService(new Intent(this, FloatingBrowserService.class));
        });
        root.addView(btnStop);

        TextView help = new TextView(this);
        help.setTextSize(13);
        help.setTextColor(Color.parseColor("#555B6E"));
        help.setPadding(0, dp(20), 0, dp(12));
        help.setText("Beranda:\n"
                + "\u2022 Isi alamat/kata kunci lalu tekan Buka, atau ketuk salah satu ikon situs.\n"
                + "\u2022 Tombol + Tambah situs menyimpan situs favorit ke beranda.\n"
                + "\u2022 Riwayat kunjungan tersimpan otomatis; bisa dihapus satu-satu atau semuanya.\n"
                + "\u2022 Tersedia tombol Hapus Cookie & Sesi (membuat logout dari semua situs) dan Hapus Cache "
                + "(hanya membersihkan cache halaman \u2014 cookie & login tetap tersimpan).\n"
                + "\u2022 Zoom Halaman (slider/preset di Beranda, default 65%) mengatur besar teks "
                + "dan gambar pada semua situs yang dibuka. Beranda tidak ikut di-zoom.\n"
                + "Cara pakai jendela:\n"
                + "\u2022 Geser jendela: tahan bilah gelap di bagian atas jendela lalu geser.\n"
                + "\u2022 Ubah ukuran: tarik ikon \u25E2 di ujung kanan toolbar (bilah gelap atas jendela). "
                + "Halaman web otomatis menyesuaikan (tidak menumpuk) saat jendela diperkecil/diperbesar.\n"
                + "\u2022 Tombol \u2302 (home): kembali ke Beranda kapan saja.\n"
                + "\u2022 Tombol \u2606 (bintang): menandai/menghapus bookmark situs yang sedang dibuka.\n"
                + "\u2022 Tombol \u2328 (keyboard): mengaktifkan/menonaktifkan mode ketik untuk halaman web. "
                + "Saat NONAKTIF (bawaan), ketikan dan sentuhan di luar jendela diteruskan ke aplikasi di bawah.\n"
                + "\u2022 \u25C0 \u25B6 \u27F3: kembali, maju, muat ulang halaman.\n"
                + "\u2022 Tombol \u25BC di toolbar (sebelah \u2715): menyembunyikan jendela menjadi gelembung bulat biru. "
                + "Ketuk gelembungnya untuk memunculkan jendela lagi (gelembung juga bisa digeser). "
                + "Saat tersembunyi, video/audio dijeda dan aktivitas halaman dihentikan sementara "
                + "agar hemat baterai dan tidak panas.\n"
                + "\u2022 Salin teks: tahan (long-press) teks di halaman web \u2014 muncul bar "
                + "\"Salin / Pilih semua / Batal\" di bagian bawah, ketuk Salin.\n"
                + "\u2022 Tombol \u2715: menutup jendela browser.");
        root.addView(help);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
            launchPip();
        }
    }

    private void launchPip() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            toast("Beri izin \"Tampil di atas aplikasi lain\" dulu");
            requestOverlayPermission();
            return;
        }
        Intent svc = new Intent(this, FloatingBrowserService.class);
        svc.setAction(FloatingBrowserService.isRunning()
                ? FloatingBrowserService.ACTION_SHOW
                : FloatingBrowserService.ACTION_HOME);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
        moveTaskToBack(true);
    }

    private void refreshStatus() {
        boolean overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        boolean notif = true;
        if (Build.VERSION.SDK_INT >= 33) {
            notif = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED;
        }
        String overlayText = overlay ? "SUDAH diberikan" : "BELUM diberikan";
        String notifText = notif ? "SUDAH diberikan" : "BELUM diberikan (opsional)";
        statusView.setText("Status izin:\n"
                + "\u2022 Tampil di atas aplikasi lain: " + overlayText + "\n"
                + "\u2022 Notifikasi: " + notifText);
        if (overlay) {
            statusView.setBackgroundColor(Color.parseColor("#DFF5E1"));
            statusView.setTextColor(Color.parseColor("#1B5E20"));
        } else {
            statusView.setBackgroundColor(Color.parseColor("#FDE7E9"));
            statusView.setTextColor(Color.parseColor("#B71C1C"));
        }
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT < 23) {
            toast("Di versi Android ini izin tampil di atas aplikasi otomatis diberikan");
            return;
        }
        if (Settings.canDrawOverlays(this)) {
            toast("Izin sudah diberikan");
            return;
        }
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, REQ_OVERLAY);
    }

    private void requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        } else {
            toast("Tidak perlu izin notifikasi di perangkat ini");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        refreshStatus();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshStatus();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
