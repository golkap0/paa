========================================================================
PIP FLOAT BROWSER  v2.2 (versionCode 13)
Browser jendela melayang (floating/PIP) untuk Android
========================================================================

TENTANG APLIKASI
----------------
Browser yang tampil sebagai jendela melayang di atas aplikasi lain
(TikTok, WhatsApp, game, dll). Aplikasi di bawahnya TETAP NORMAL:
sentuhan dan keyboard di luar jendela diteruskan ke aplikasi di bawah.

PENYIMPANAN FILE (per versi, terpisah):
APK    : /content/apk/PIP_Float_Browser_v2.2.apk
         (versi lama tetap tersimpan, mis. v2.0, v2.1)
SHA-256: f96bcc8720ab1b81fb16d9a6227c56e01685f66906ee0f438eb9cf050c82031e
Source : /content/source/PIP_Float_Browser_v2.2_source.zip
Paket  : com.floatbrowser.pip
Requirement: Android 5.0+ (minSdk 21), target Android 14 (targetSdk 34)

FITUR
-----
1. Beranda bawaan (tombol ⌂): input alamat/pencarian, ikon situs default
   (fas77.fxtun.dev dan myip.id), tombol "+ Tambah situs", dan riwayat.
2. Bookmark: tombol ☆ pada toolbar menandai/menghapus situs yang sedang
   dibuka. Bintang kuning (★) = sudah tersimpan. Situs bookmarked muncul
   sebagai ikon di Beranda dan bisa dihapus (×) dari sana.
3. Riwayat: tersimpan otomatis (maks 300, tampil 40 terakhir). Hapus
   satu-satu lewat tombol × atau semuanya lewat "Bersihkan Riwayat".
4. Privasi: tombol "Hapus Cookie & Sesi" dan "Hapus Cache" di Beranda.
5. Buka langsung ke PIP: begitu izin "Tampil di atas aplikasi lain"
   diberikan, browser langsung terbuka sebagai jendela melayang di
   Beranda, lalu app mengecil ke belakang. Tidak ada layar input URL.
6. Jendela bisa digeser (tahan bilah gelap atas), diubah ukurannya
   (tarik ikon ◢ di ujung kanan toolbar), halaman web otomatis
   menyesuaikan. Tidak ada tombol melayang di sudut jendela, jadi
   tombol situs web (mis. kontrol video di bawah) tidak terhalang.
7. Tombol ▼ di toolbar (sebelah ✕) menyembunyikan jendela menjadi
   gelembung bulat biru (bisa digeser, ketuk untuk memunculkan lagi).
8. Tombol ⌨ = mode keyboard: saat AKTIF, keyboard di dalam jendela
   menangkap ketikan; saat NONAKTIF (bawaan), semua diteruskan ke
   aplikasi di bawah.
9. Video fullscreen (mis. YouTube) otomatis diperbesar di dalam jendela.
10. Situs yang hanya mendukung salah satu skema dicoba otomatis:
    https gagal -> dicoba http, dan sebaliknya (sekali per alamat).
    Situs ber-sertifikat bermasalah tetap dibuka (SSL dilanjutkan).
11. Ikon situs & riwayat di Beranda adalah link asli, jadi selalu bisa
    diklik-buka meskipun JavaScript halaman bermasalah.
12. Ikon aplikasi tampil normal di daftar Recent Apps (task tidak
    dikosongkan + TaskDescription + adaptive icon Android 8+).
13. Zoom Halaman (seperti pengaturan aksesibilitas Chrome): slider dan
    preset di Beranda mengatur besar teks & gambar pada SEMUA situs
    yang dibuka. Default 65%, rentang 25%-200%. Konten selalu pas
    mengisi jendela (tidak ada ruang kosong). Pilihan tersimpan
    permanen. Beranda tidak ikut di-zoom.
14. Tidak ada auto-zoom saat mengetik: mengetuk kolom isian atau mulai
    menulis tidak lagi membuat halaman tiba-tiba membesar (ukuran font
    kolom isian otomatis dijaga minimal 16px efektif di semua tingkat
    zoom).
15. Hemat baterai & anti-panas (v1.9):
    - Video/audio tidak autoplay (perlu ketuk, seperti Chrome) sehingga
      situs iklan tidak memutar media sendiri.
    - Saat jendela disembunyikan jadi gelembung: video/audio dijeda,
      animasi dan semua timer/JavaScript WebView dihentikan sementara
      (WebView.pauseTimers + onPause), lalu dilanjutkan otomatis saat
      jendela dibuka lagi. Halaman tetap di posisi terakhir.
    - Tidak ada wakelock/AlarmManager; notifikasi senyap (tanpa suara,
      getar, atau update berkala).
    - Saat aplikasi ditutup: semua callback Handler dibatalkan,
      JavaScript interface dilepas, dan WebView dihancurkan sehingga
      tidak ada memori yang nyangkut.
16. Salin teks (v2.1): tahan (long-press) teks di halaman web — bar
    "Salin / Pilih semua / Batal" muncul di bagian bawah jendela
    (milik aplikasi sendiri, tidak bergantung menu bawaan Android yang
    sering tidak muncul di jendela melayang). Ketuk Salin untuk
    menyalin; "Pilih semua" menyalin seluruh teks halaman. Menu
    bawaan Android tetap diaktifkan otomatis bila perangkat
    mendukung. Berlaku juga untuk "Salin alamat tautan".

CARA PAKAI
----------
1. Pasang APK, buka aplikasinya.
2. Beri izin "Tampil di atas aplikasi lain" (wajib) dan izin Notifikasi
   (Android 13+, opsional). Setelah izin overlay diberikan, jendela
   browser langsung muncul di Beranda.
3. Isi alamat di Beranda lalu tekan Buka, atau ketuk ikon situs.
4. Buka aplikasi lain; jendela browser tetap melayang di atasnya.
   Membuka lagi app ini dari launcher/recent akan memunculkan kembali
   jendela (jika tersembunyi) lalu app kembali ke belakang otomatis.
5. Untuk menutup: tombol ✕ pada jendela, atau aksi "Tutup" di
   notifikasi.

CATATAN
-------
- Beberapa situs tidak bisa di-scroll dari dalam jendela karena situsnya
  sendiri memakai iframe/scroller khusus. Ini keterbatasan situs, bukan
  bug aplikasi.
- Tidak ada fitur di luar daftar di atas; jangan berharap tab ganda,
  ekstensi, download manager, dsb.

CARA BUILD ULANG (untuk developer)
----------------------------------
WAJIB JDK 17 (JDK 21/lebih baru GAGAL di JdkImageTransform):

    export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
    cd FloatBrowser
    /content/tools/gradle-8.9/bin/gradle assembleRelease --no-daemon

Hasil : app/build/outputs/apk/release/app-release.apk
SDK   : /content/android-sdk (build-tools 34.0.0, platforms;android-34)

Verifikasi tanda tangan (harus v1/v2/v3 = true, agar tidak gagal
dipasang di HP):

    /content/android-sdk/build-tools/34.0.0/apksigner verify -v app-release.apk

Keystore release (JANGAN diganti, agar update menimpa versi lama tanpa
uninstall):
    File   : keystore/floatbrowser.keystore
    Store  : floatbrowser123
    Alias  : floatbrowser
    Key    : floatbrowser123

Ikon launcher bisa dibuat ulang dengan: python3 gen_icons.py

Baca file konteks.txt untuk detail arsitektur dan aturan pengembangan.
========================================================================
