package com.floatbrowser.pip;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashSet;

public class FloatingBrowserService extends Service {

    public static final String ACTION_CLOSE = "com.floatbrowser.pip.CLOSE";
    public static final String ACTION_SHOW = "com.floatbrowser.pip.SHOW";
    public static final String ACTION_HOME = "com.floatbrowser.pip.HOME";
    public static final String EXTRA_URL = "extra_url";

    private static final String CHANNEL_ID = "floating_browser_channel";
    private static final int NOTIF_ID = 42;
    private static final int MIN_LAYOUT_WIDTH_CSS = 320;
    private static final int BUBBLE_SIZE_DP = 54;
    private static final String HOME_BASE = "https://home.floatbrowser.local/";
    private static final String PREFS = "float_browser_prefs";
    private static final String KEY_BOOKMARKS = "bookmarks_json";
    private static final String KEY_HISTORY = "history_json";
    private static final int HISTORY_LIMIT = 300;
    private static final int HISTORY_SHOW = 40;
    private static final String KEY_ZOOM = "zoom_percent";
    private static final int ZOOM_DEFAULT = 65;
    private static final int ZOOM_MIN = 25;
    private static final int ZOOM_MAX = 200;

    private static volatile boolean sRunning = false;

    public static boolean isRunning() {
        return sRunning;
    }

    private WindowManager windowManager;
    private WindowManager.LayoutParams params;

    private FrameLayout rootView;
    private LinearLayout toolbar;
    private FrameLayout webContainer;
    private WebView webView;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private EditText urlBar;
    private ProgressBar progressBar;
    private TextView resizeHandle;

    private boolean focusMode = false;
    private boolean homeActive = false;
    private boolean selectionFocusPending = false;
    private boolean selectionFocusAuto = false;
    private int[] savedSize = null;
    private boolean windowHidden = false;
    private int[] preHideSize = null;
    private boolean timersPaused = false;

    private LinearLayout columnView;
    private ImageView bubbleView;
    private TextView dragHandleView;
    private TextView btnForwardView;
    private TextView btnReloadView;
    private TextView btnStarView;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable reflowRunnable = this::applyResponsiveViewport;
    private final Runnable selectionUndo = () -> {
        if (selectionFocusPending) {
            selectionFocusPending = false;
            setFocusMode(false);
        }
    };
    private final Runnable configRunnable = () -> {
        if (rootView != null && params != null) {
            clampPositionAndSize();
            windowManager.updateViewLayout(rootView, params);
            scheduleResponsiveViewport();
        }
    };
    private final HashSet<String> retriedHttp = new HashSet<>();

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        sRunning = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_CLOSE.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        startForegroundCompat();

        if (!canDrawOverlays()) {
            toast("Izin \"Tampil di Atas Aplikasi Lain\" belum diberikan.");
            stopSelf();
            return START_NOT_STICKY;
        }

        if (rootView == null) {
            buildOverlay();
        }
        if (windowHidden) {
            restoreWindow();
        }

        if (ACTION_SHOW.equals(action) && webView != null && webView.getUrl() != null) {
            return START_NOT_STICKY;
        }

        String url = intent != null ? intent.getStringExtra(EXTRA_URL) : null;
        if (TextUtils.isEmpty(url)) {
            loadHome();
        } else {
            loadUrl(normalizeUrl(url));
        }

        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------------ setup

    @SuppressLint("SetJavaScriptEnabled")
    private void buildOverlay() {
        int[] screen = getScreenSize();
        int initialW = Math.min(screen[0] * 92 / 100, dp(560));
        int initialH = screen[1] * 48 / 100;

        rootView = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.parseColor("#33000000"));
        rootView.setBackground(bg);
        rootView.setClipToOutline(true);

        columnView = new LinearLayout(this);
        columnView.setOrientation(LinearLayout.VERTICAL);
        rootView.addView(columnView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable tb = new GradientDrawable();
        tb.setColor(Color.parseColor("#1F2430"));
        tb.setCornerRadii(new float[]{dp(14), dp(14), dp(14), dp(14), 0, 0, 0, 0});
        toolbar.setBackground(tb);
        toolbar.setPadding(dp(6), 0, dp(6), 0);
        columnView.addView(toolbar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        dragHandleView = makeToolButton("\u22EE\u22EE");
        dragHandleView.setTextSize(16);
        dragHandleView.setContentDescription("Geser jendela");
        toolbar.addView(dragHandleView);

        TextView btnHome = makeToolButton("\u2302");
        btnHome.setContentDescription("Beranda browser");
        btnHome.setOnClickListener(v -> loadHome());
        toolbar.addView(btnHome);

        TextView btnBack = makeToolButton("\u25C0");
        btnBack.setContentDescription("Kembali");
        btnBack.setOnClickListener(v -> {
            if (webView != null && webView.canGoBack()) webView.goBack();
        });
        toolbar.addView(btnBack);

        btnForwardView = makeToolButton("\u25B6");
        btnForwardView.setContentDescription("Maju");
        btnForwardView.setOnClickListener(v -> {
            if (webView != null && webView.canGoForward()) webView.goForward();
        });
        toolbar.addView(btnForwardView);

        btnReloadView = makeToolButton("\u27F3");
        btnReloadView.setContentDescription("Muat ulang");
        btnReloadView.setOnClickListener(v -> {
            if (webView != null) webView.reload();
        });
        toolbar.addView(btnReloadView);

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setTextSize(13);
        urlBar.setTextColor(Color.WHITE);
        urlBar.setHintTextColor(Color.parseColor("#8892A6"));
        urlBar.setHint("Ketik alamat / pencarian\u2026");
        urlBar.setBackgroundColor(Color.parseColor("#2E3547"));
        urlBar.setPadding(dp(10), 0, dp(10), 0);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(0, dp(34), 1f);
        urlLp.setMargins(dp(4), 0, dp(4), 0);
        toolbar.addView(urlBar, urlLp);

        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                String text = urlBar.getText().toString().trim();
                if (text.isEmpty()) {
                    loadHome();
                } else {
                    loadUrl(normalizeUrl(text));
                }
                hideKeyboard();
                setFocusMode(false);
                return true;
            }
            return false;
        });
        urlBar.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN && !focusMode) {
                setFocusMode(true);
                urlBar.requestFocus();
                uiHandler.postDelayed(() -> showKeyboard(urlBar), 120);
            }
            return false;
        });

        btnStarView = makeToolButton("\u2606");
        btnStarView.setContentDescription("Simpan/hapus bookmark");
        btnStarView.setOnClickListener(v -> toggleBookmark());
        toolbar.addView(btnStarView);

        TextView btnGo = makeToolButton("\u23CE");
        btnGo.setContentDescription("Buka alamat");
        btnGo.setOnClickListener(v -> {
            String text = urlBar.getText().toString().trim();
            if (text.isEmpty()) {
                loadHome();
            } else {
                loadUrl(normalizeUrl(text));
            }
            hideKeyboard();
            setFocusMode(false);
        });
        toolbar.addView(btnGo);

        TextView btnKeyboard = makeToolButton("\u2328");
        btnKeyboard.setContentDescription("Mode keyboard");
        btnKeyboard.setOnClickListener(v -> toggleFocusMode());
        toolbar.addView(btnKeyboard);

        TextView btnHide = makeToolButton("\u25BC");
        btnHide.setContentDescription("Sembunyikan jendela");
        btnHide.setOnClickListener(v -> hideWindow());
        toolbar.addView(btnHide);

        TextView btnClose = makeToolButton("\u2715");
        btnClose.setContentDescription("Tutup jendela");
        btnClose.setTextColor(Color.parseColor("#FF6B6B"));
        btnClose.setOnClickListener(v -> stopSelf());
        toolbar.addView(btnClose);

        resizeHandle = makeToolButton("\u25E2");
        resizeHandle.setTextSize(13);
        resizeHandle.setContentDescription("Ubah ukuran jendela");
        toolbar.addView(resizeHandle);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        columnView.addView(progressBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        webContainer = new FrameLayout(this);
        columnView.addView(webContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        webView = new SelectWebView(this);
        webView.addJavascriptInterface(new HomeBridge(), "Android");
        WebSettings s = webView.getSettings();
        String ua = s.getUserAgentString();
        if (ua != null) {
            ua = ua.replace("; wv", "")
                    .replaceAll(" Build/[^;)]+", "")
                    .replace("Version/4.0 ", "");
            s.setUserAgentString(ua);
        }
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                homeActive = HOME_BASE.equals(url);
                if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
                updateUrlBar(url);
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                applyResponsiveViewport();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (progressBar != null) progressBar.setVisibility(View.GONE);
                updateUrlBar(url);
                applyResponsiveViewport();
                if (!isHome()) injectCopySupport();
                if (isRealPage(url)) {
                    recordHistory(url, view.getTitle());
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= 23 && request != null && request.isForMainFrame()
                        && error != null) {
                    handleMainFrameError(request.getUrl() != null ? request.getUrl().toString() : null,
                            error.getErrorCode());
                }
            }

            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (Build.VERSION.SDK_INT < 23) {
                    handleMainFrameError(failingUrl, errorCode);
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler,
                                           android.net.http.SslError error) {
                handler.proceed();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (progressBar == null) return;
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog,
                                          boolean isUserGesture, Message resultMsg) {
                WebView.HitTestResult result = view.getHitTestResult();
                String data = result != null ? result.getExtra() : null;
                if (data != null && (data.startsWith("http://") || data.startsWith("https://"))) {
                    view.loadUrl(data);
                }
                return false;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                webView.setVisibility(View.GONE);
                webContainer.addView(customView, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                savedSize = new int[]{params.width, params.height};
                int[] scr = getScreenSize();
                params.width = scr[0];
                params.height = scr[1] * 80 / 100;
                clampPositionAndSize();
                windowManager.updateViewLayout(rootView, params);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                webContainer.removeView(customView);
                customView = null;
                webView.setVisibility(View.VISIBLE);
                if (savedSize != null) {
                    params.width = savedSize[0];
                    params.height = savedSize[1];
                    savedSize = null;
                    clampPositionAndSize();
                    windowManager.updateViewLayout(rootView, params);
                }
                if (customViewCallback != null) {
                    customViewCallback.onCustomViewHidden();
                    customViewCallback = null;
                }
                scheduleResponsiveViewport();
            }
        });

        webContainer.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        bubbleView = new ImageView(this);
        bubbleView.setImageResource(R.drawable.ic_stat_browser);
        GradientDrawable bubbleBg = new GradientDrawable();
        bubbleBg.setShape(GradientDrawable.OVAL);
        bubbleBg.setColor(Color.parseColor("#3A57E8"));
        bubbleView.setBackground(bubbleBg);
        int bubblePad = dp(13);
        bubbleView.setPadding(bubblePad, bubblePad, bubblePad, bubblePad);
        bubbleView.setContentDescription("Tampilkan jendela browser");
        bubbleView.setVisibility(View.GONE);
        rootView.addView(bubbleView, new FrameLayout.LayoutParams(
                dp(BUBBLE_SIZE_DP), dp(BUBBLE_SIZE_DP)));

        int windowType = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                initialW, initialH, windowType,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = Math.max(0, (screen[0] - initialW) / 2);
        params.y = dp(90);
        params.setTitle("FloatingBrowser");

        setUpDragHandle(dragHandleView);
        setUpResizeHandle();
        setUpBubbleTouch();

        try {
            windowManager.addView(rootView, params);
        } catch (Exception e) {
            toast("Gagal membuka jendela: " + e.getMessage());
            stopSelf();
        }
        adaptToolbar();
        applyResponsiveViewport();
    }

    private void injectCopySupport() {
        if (webView == null || isHome()) return;
        String js = "(function(){try{"
                + "if(window.__fbCopy)return;window.__fbCopy=1;"
                + "var bar=null;"
                + "function hideBar(){if(bar&&bar.parentNode){bar.parentNode.removeChild(bar);}bar=null;}"
                + "function showBar(){if(bar){return;}"
                + "bar=document.createElement('div');"
                + "bar.style.cssText='position:fixed;left:50%;transform:translateX(-50%);bottom:18px;"
                + "z-index:2147483647;display:flex;gap:8px;padding:8px 10px;background:#1F2430;"
                + "border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,.4);font-family:sans-serif;';"
                + "var b1=document.createElement('button');b1.textContent='Salin';"
                + "b1.style.cssText='background:#3A57E8;color:#fff;border:0;border-radius:7px;padding:8px 16px;font-size:14px;';"
                + "b1.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();doCopy();});"
                + "var b2=document.createElement('button');b2.textContent='Pilih semua';"
                + "b2.style.cssText='background:#2E3547;color:#fff;border:0;border-radius:7px;padding:8px 14px;font-size:14px;';"
                + "b2.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();"
                + "try{var r=document.createRange();r.selectNodeContents(document.body);"
                + "var s=window.getSelection();s.removeAllRanges();s.addRange(r);doCopy();}catch(err){}});"
                + "var b3=document.createElement('button');b3.textContent='Batal';"
                + "b3.style.cssText='background:#2E3547;color:#C9CEDE;border:0;border-radius:7px;padding:8px 12px;font-size:14px;';"
                + "b3.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();"
                + "try{window.getSelection().removeAllRanges();}catch(err){}hideBar();});"
                + "bar.appendChild(b1);bar.appendChild(b2);bar.appendChild(b3);"
                + "if(document.body){document.body.appendChild(bar);}}"
                + "function doCopy(){try{var s=window.getSelection();var t=s?s.toString():'';"
                + "t=t.replace(/\\s+/g,' ').trim();"
                + "if(t&&window.Android&&window.Android.copyText){window.Android.copyText(t);}"
                + "if(s){s.removeAllRanges();}}catch(err){}hideBar();}"
                + "function pickWord(x,y){try{var r=null;"
                + "if(document.caretRangeFromPoint){r=document.caretRangeFromPoint(x,y);}"
                + "else if(document.caretPositionFromPoint){var p=document.caretPositionFromPoint(x,y);"
                + "if(p){r=document.createRange();r.setStart(p.offsetNode,p.offset);}}"
                + "if(!r){return false;}var n=r.startContainer;"
                + "if(n&&n.nodeType===3){var tx=n.textContent,off=r.startOffset,a=off,b=off;"
                + "while(a>0&&!/\\s/.test(tx.charAt(a-1))){a--;}"
                + "while(b<tx.length&&!/\\s/.test(tx.charAt(b))){b++;}"
                + "var rg=document.createRange();rg.setStart(n,a);rg.setEnd(n,b);"
                + "var s=window.getSelection();s.removeAllRanges();s.addRange(rg);return true;}"
                + "}catch(err){}return false;}"
                + "var timer=null,sx=0,sy=0;"
                + "document.addEventListener('touchstart',function(e){"
                + "if(e.touches.length!==1){return;}var t=e.touches[0];sx=t.clientX;sy=t.clientY;"
                + "clearTimeout(timer);"
                + "timer=setTimeout(function(){if(pickWord(sx,sy)){showBar();"
                + "if(window.Android&&window.Android.holdSelect){window.Android.holdSelect();}}},450);"
                + "},true);"
                + "document.addEventListener('touchmove',function(e){"
                + "if(e.touches.length!==1){clearTimeout(timer);return;}"
                + "var t=e.touches[0];"
                + "if(Math.abs(t.clientX-sx)>12||Math.abs(t.clientY-sy)>12){clearTimeout(timer);}"
                + "},true);"
                + "document.addEventListener('touchend',function(){clearTimeout(timer);},true);"
                + "document.addEventListener('touchcancel',function(){clearTimeout(timer);},true);"
                + "document.addEventListener('selectionchange',function(){"
                + "try{var t=window.getSelection().toString().trim();"
                + "if(t&&!bar){showBar();}else if(!t&&bar){hideBar();}}catch(err){}});"
                + "}catch(e){}})();";
        webView.evaluateJavascript(js, null);
    }

    private class SelectWebView extends WebView {
        SelectWebView(Context context) {
            super(context);
        }

        @Override
        public void onWindowFocusChanged(boolean hasWindowFocus) {
            super.onWindowFocusChanged(hasWindowFocus);
            if (!hasWindowFocus && selectionFocusAuto) {
                selectionFocusAuto = false;
                selectionFocusPending = false;
                setFocusMode(false);
            }
        }

        @Override
        public ActionMode startActionMode(ActionMode.Callback callback) {
            return super.startActionMode(prepareSelectionFocus(callback));
        }

        @Override
        public ActionMode startActionMode(ActionMode.Callback callback, int type) {
            return super.startActionMode(prepareSelectionFocus(callback), type);
        }

        private ActionMode.Callback prepareSelectionFocus(ActionMode.Callback callback) {
            if (callback == null) return null;
            if (!focusMode) {
                selectionFocusPending = true;
                setFocusMode(true);
                requestFocus();
            }
            if (selectionFocusPending) {
                selectionFocusAuto = true;
                selectionFocusPending = false;
            }
            return new ActionMode.Callback() {
                @Override
                public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                    return callback.onCreateActionMode(mode, menu);
                }

                @Override
                public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                    return callback.onPrepareActionMode(mode, menu);
                }

                @Override
                public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                    return callback.onActionItemClicked(mode, item);
                }

                @Override
                public void onDestroyActionMode(ActionMode mode) {
                    callback.onDestroyActionMode(mode);
                    if (selectionFocusAuto) {
                        selectionFocusAuto = false;
                        setFocusMode(false);
                    }
                }
            };
        }
    }

    private void updateUrlBar(String url) {
        if (urlBar == null || url == null) return;
        if (!urlBar.hasFocus()) {
            if (HOME_BASE.equals(url)) {
                urlBar.setText("");
            } else {
                urlBar.setText(url);
            }
        }
        updateStar(url);
    }

    private TextView makeToolButton(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(5), 0, dp(5), 0);
        tv.setMinWidth(dp(26));
        tv.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        tv.setBackgroundColor(Color.TRANSPARENT);
        return tv;
    }

    private void setUpDragHandle(View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        startX = params.x;
                        startY = params.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + (int) (e.getRawX() - downRawX);
                        params.y = startY + (int) (e.getRawY() - downRawY);
                        clampPositionAndSize();
                        windowManager.updateViewLayout(rootView, params);
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void setUpResizeHandle() {
        resizeHandle.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startW, startH;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        startW = params.width;
                        startH = params.height;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int w = startW + (int) (e.getRawX() - downRawX);
                        int h = startH + (int) (e.getRawY() - downRawY);
                        params.width = Math.max(dp(260), w);
                        params.height = Math.max(dp(200), h);
                        clampPositionAndSize();
                        windowManager.updateViewLayout(rootView, params);
                        if (webView != null) webView.requestLayout();
                        scheduleResponsiveViewport();
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        scheduleResponsiveViewport();
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    // -------------------------------------------------------------- hide/show

    private void hideWindow() {
        if (windowHidden || rootView == null || params == null) return;
        if (focusMode) setFocusMode(false);
        preHideSize = new int[]{params.width, params.height};
        windowHidden = true;
        columnView.setVisibility(View.GONE);
        GradientDrawable bubbleBg = new GradientDrawable();
        bubbleBg.setShape(GradientDrawable.OVAL);
        bubbleBg.setColor(Color.parseColor("#3A57E8"));
        rootView.setBackground(bubbleBg);
        bubbleView.setVisibility(View.VISIBLE);
        params.width = dp(BUBBLE_SIZE_DP);
        params.height = dp(BUBBLE_SIZE_DP);
        clampPositionAndSize();
        windowManager.updateViewLayout(rootView, params);
        pauseWebActivity();
        toast("Jendela disembunyikan. Ketuk gelembung biru untuk membuka lagi.");
    }

    private void restoreWindow() {
        if (!windowHidden || rootView == null || params == null) return;
        windowHidden = false;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.parseColor("#33000000"));
        rootView.setBackground(bg);
        bubbleView.setVisibility(View.GONE);
        columnView.setVisibility(View.VISIBLE);
        if (preHideSize != null) {
            params.width = preHideSize[0];
            params.height = preHideSize[1];
            preHideSize = null;
        }
        clampPositionAndSize();
        windowManager.updateViewLayout(rootView, params);
        resumeWebActivity();
        scheduleResponsiveViewport();
    }

    private void pauseWebActivity() {
        if (webView == null) return;
        try {
            webView.evaluateJavascript(
                    "(function(){try{var ms=document.querySelectorAll('video,audio');"
                            + "for(var i=0;i<ms.length;i++){try{ms[i].pause();}catch(e){}}}catch(e){}})();",
                    null);
        } catch (Exception ignored) {
        }
        webView.onPause();
        webView.pauseTimers();
        timersPaused = true;
    }

    private void resumeWebActivity() {
        if (webView == null) return;
        webView.onResume();
        if (timersPaused) {
            webView.resumeTimers();
            timersPaused = false;
        }
    }

    private void setUpBubbleTouch() {
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        startX = params.x;
                        startY = params.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        int dx = (int) (e.getRawX() - downRawX);
                        int dy = (int) (e.getRawY() - downRawY);
                        if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true;
                        if (moved) {
                            params.x = startX + dx;
                            params.y = startY + dy;
                            clampPositionAndSize();
                            windowManager.updateViewLayout(rootView, params);
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (!moved) restoreWindow();
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    // ------------------------------------------------------------ focus mode

    private void setFocusMode(boolean on) {
        if (focusMode == on || params == null || rootView == null) return;
        focusMode = on;
        if (on) {
            params.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        } else {
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            selectionFocusPending = false;
            rootView.clearFocus();
            hideKeyboard();
        }
        windowManager.updateViewLayout(rootView, params);
    }

    private void toggleFocusMode() {
        setFocusMode(!focusMode);
        if (focusMode) {
            toast("Mode ketik AKTIF: keyboard dipakai untuk jendela browser ini");
            if (urlBar != null) {
                urlBar.requestFocus();
                uiHandler.postDelayed(() -> showKeyboard(urlBar), 120);
            }
        } else {
            toast("Mode ketik NONAKTIF: sentuhan & keyboard diteruskan ke aplikasi di bawah");
        }
    }

    private void showKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null && v != null) {
            imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT);
        }
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null && rootView != null && rootView.getWindowToken() != null) {
            imm.hideSoftInputFromWindow(rootView.getWindowToken(), 0);
        }
    }

    // -------------------------------------------------------------- utilities

    // ------------------------------------------------------------- home page

    private boolean isHome() {
        if (webView == null) return false;
        return homeActive || HOME_BASE.equals(webView.getUrl());
    }

    private boolean isRealPage(String url) {
        if (url == null) return false;
        return (url.startsWith("http://") || url.startsWith("https://"))
                && !url.startsWith(HOME_BASE);
    }

    private void loadHome() {
        if (webView == null) return;
        if (rootView != null && windowHidden) {
            restoreWindow();
        }
        homeActive = true;
        webView.loadDataWithBaseURL(HOME_BASE, buildHomeHtml(), "text/html", "utf-8", null);
    }

    private String buildHomeHtml() {
        String defaults = "[{\"u\":\"http://fas77.fxtun.dev\",\"t\":\"fas77\"},"
                + "{\"u\":\"https://myip.id\",\"t\":\"myip.id\"}]";
        JSONArray bookmarks = getArray(KEY_BOOKMARKS);
        JSONArray history = getArray(KEY_HISTORY);
        JSONArray historyShow = new JSONArray();
        for (int i = 0; i < history.length() && i < HISTORY_SHOW; i++) {
            JSONObject o = history.optJSONObject(i);
            if (o != null) historyShow.put(o);
        }
        String template = readRawResource(R.raw.home);
        return template
                .replace("__DEFAULTS__", sanitizeForScript(defaults))
                .replace("__BOOKMARKS__", sanitizeForScript(bookmarks.toString()))
                .replace("__HISTORY__", sanitizeForScript(historyShow.toString()))
                .replace("__ZOOM__", String.valueOf(getZoomPercent()));
    }

    private String sanitizeForScript(String json) {
        return json.replace("<", "\\u003c")
                .replace("\u2028", "\\u2028")
                .replace("\u2029", "\\u2029");
    }

    private String readRawResource(int resId) {
        try (InputStream is = getResources().openRawResource(resId)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return new String(out.toByteArray(), "UTF-8");
        } catch (Exception e) {
            return "<html><body style=\"background:#12151E;color:#fff;font-family:sans-serif;padding:20px\">"
                    + "Beranda gagal dimuat.</body></html>";
        }
    }

    // ------------------------------------------------------- bookmarks/history

    private JSONArray getArray(String key) {
        try {
            return new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void putArray(String key, JSONArray arr) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(key, arr.toString()).apply();
    }

    private boolean isBookmarked(String url) {
        JSONArray arr = getArray(KEY_BOOKMARKS);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && url != null && url.equals(o.optString("u"))) return true;
        }
        return false;
    }

    private void addBookmarkInternal(String url, String title) {
        JSONArray arr = getArray(KEY_BOOKMARKS);
        JSONArray out = new JSONArray();
        try {
            JSONObject entry = new JSONObject();
            entry.put("u", url);
            entry.put("t", TextUtils.isEmpty(title) ? url : title);
            out.put(entry);
            for (int i = 0; i < arr.length() && out.length() < 100; i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null || url.equals(o.optString("u"))) continue;
                out.put(o);
            }
        } catch (Exception ignored) {
        }
        putArray(KEY_BOOKMARKS, out);
    }

    private void removeBookmarkInternal(String url) {
        JSONArray arr = getArray(KEY_BOOKMARKS);
        JSONArray out = new JSONArray();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null || url.equals(o.optString("u"))) continue;
            out.put(o);
        }
        putArray(KEY_BOOKMARKS, out);
    }

    private void recordHistory(String url, String title) {
        if (!isRealPage(url)) return;
        try {
            JSONArray arr = getArray(KEY_HISTORY);
            JSONArray out = new JSONArray();
            JSONObject entry = new JSONObject();
            entry.put("u", url);
            entry.put("t", TextUtils.isEmpty(title) ? url : title);
            entry.put("ts", System.currentTimeMillis() / 1000);
            out.put(entry);
            for (int i = 0; i < arr.length() && out.length() < HISTORY_LIMIT; i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null || url.equals(o.optString("u"))) continue;
                out.put(o);
            }
            putArray(KEY_HISTORY, out);
        } catch (Exception ignored) {
        }
    }

    private void removeHistoryInternal(String url) {
        JSONArray arr = getArray(KEY_HISTORY);
        JSONArray out = new JSONArray();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null || url.equals(o.optString("u"))) continue;
            out.put(o);
        }
        putArray(KEY_HISTORY, out);
    }

    private void toggleBookmark() {
        String url = webView != null ? webView.getUrl() : null;
        if (!isRealPage(url)) {
            toast("Buka situs dulu untuk menandai bookmark");
            return;
        }
        if (isBookmarked(url)) {
            removeBookmarkInternal(url);
            toast("Bookmark dihapus");
        } else {
            String title = webView.getTitle();
            addBookmarkInternal(url, TextUtils.isEmpty(title) ? url : title);
            toast("Ditambahkan ke bookmark");
        }
        updateStar(url);
    }

    private void updateStar(String url) {
        if (btnStarView == null) return;
        boolean marked = isRealPage(url) && isBookmarked(url);
        btnStarView.setText(marked ? "\u2605" : "\u2606");
        btnStarView.setTextColor(marked ? Color.parseColor("#FFD166") : Color.WHITE);
    }

    // ------------------------------------------------------------------- zoom

    private int getZoomPercent() {
        int z = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_ZOOM, ZOOM_DEFAULT);
        if (z < ZOOM_MIN) z = ZOOM_MIN;
        if (z > ZOOM_MAX) z = ZOOM_MAX;
        return z;
    }

    private void setZoomPercent(int z) {
        if (z < ZOOM_MIN) z = ZOOM_MIN;
        if (z > ZOOM_MAX) z = ZOOM_MAX;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_ZOOM, z).apply();
        applyResponsiveViewport();
    }

    // ----------------------------------------------------------------- privacy

    private void doClearCookies() {
        try {
            CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookies(null);
            cm.flush();
        } catch (Exception ignored) {
        }
        try {
            WebStorage.getInstance().deleteAllData();
        } catch (Exception ignored) {
        }
        toast("Cookie & sesi situs dihapus");
    }

    private void doClearCache() {
        try {
            if (webView != null) {
                webView.clearCache(true);
                webView.clearFormData();
            }
            WebStorage.getInstance().deleteAllData();
        } catch (Exception ignored) {
        }
        toast("Cache dibersihkan");
    }

    // ------------------------------------------------------------------ errors

    private void handleMainFrameError(String url, int errorCode) {
        if (url == null || webView == null) return;
        boolean retryable = errorCode == WebViewClient.ERROR_HOST_LOOKUP
                || errorCode == WebViewClient.ERROR_CONNECT
                || errorCode == WebViewClient.ERROR_TIMEOUT
                || errorCode == WebViewClient.ERROR_FAILED_SSL_HANDSHAKE;
        if (!retryable) return;
        String alt = null;
        if (url.startsWith("https://")) {
            alt = "http://" + url.substring(8);
        } else if (url.startsWith("http://")) {
            alt = "https://" + url.substring(7);
        }
        if (alt != null && !retriedHttp.contains(alt)) {
            if (retriedHttp.size() > 128) retriedHttp.clear();
            retriedHttp.add(url);
            loadUrl(alt);
        }
    }

    // ------------------------------------------------------------ home bridge

    public class HomeBridge {
        @JavascriptInterface
        public void open(String url) {
            uiHandler.post(() -> {
                if (isHome()) loadUrl(normalizeUrl(url));
            });
        }

        @JavascriptInterface
        public void requestInput() {
            uiHandler.post(() -> {
                if (!isHome() || webView == null) return;
                if (!focusMode) setFocusMode(true);
                webView.requestFocus();
                webView.evaluateJavascript(
                        "var q=document.getElementById('q');if(q){q.focus();}", null);
                uiHandler.postDelayed(() -> showKeyboard(webView), 150);
            });
        }

        @JavascriptInterface
        public void addBookmark(String url, String name) {
            uiHandler.post(() -> {
                if (!isHome()) return;
                String u = normalizeUrl(url);
                addBookmarkInternal(u, TextUtils.isEmpty(name) ? u : name.trim());
                toast("Situs ditambahkan ke beranda");
                loadHome();
            });
        }

        @JavascriptInterface
        public void removeBookmark(String url) {
            uiHandler.post(() -> {
                if (!isHome()) return;
                removeBookmarkInternal(url);
                toast("Bookmark dihapus");
                loadHome();
            });
        }

        @JavascriptInterface
        public void removeHistory(String url) {
            uiHandler.post(() -> {
                if (!isHome()) return;
                removeHistoryInternal(url);
                toast("Item riwayat dihapus");
                loadHome();
            });
        }

        @JavascriptInterface
        public void clearHistory() {
            uiHandler.post(() -> {
                if (!isHome()) return;
                putArray(KEY_HISTORY, new JSONArray());
                toast("Riwayat dibersihkan");
                loadHome();
            });
        }

        @JavascriptInterface
        public void clearCookies() {
            uiHandler.post(() -> {
                if (!isHome()) return;
                doClearCookies();
            });
        }

        @JavascriptInterface
        public void clearCache() {
            uiHandler.post(() -> {
                if (!isHome()) return;
                doClearCache();
            });
        }

        @JavascriptInterface
        public void setZoom(int percent) {
            uiHandler.post(() -> {
                if (!isHome()) return;
                setZoomPercent(percent);
            });
        }

        @JavascriptInterface
        public void holdSelect() {
            uiHandler.post(() -> {
                if (windowHidden || webView == null) return;
                if (!focusMode) {
                    selectionFocusPending = true;
                    setFocusMode(true);
                    webView.requestFocus();
                }
                uiHandler.removeCallbacks(selectionUndo);
                uiHandler.postDelayed(selectionUndo, 6000);
            });
        }

        @JavascriptInterface
        public void copyText(String text) {
            uiHandler.post(() -> {
                if (text == null || windowHidden) return;
                String t = text.trim();
                if (t.isEmpty()) return;
                if (t.length() > 100000) t = t.substring(0, 100000);
                final String out = t;
                boolean wasPending = selectionFocusPending;
                selectionFocusPending = false;
                uiHandler.removeCallbacks(selectionUndo);
                if (!focusMode) {
                    setFocusMode(true);
                    selectionFocusAuto = true;
                } else if (wasPending) {
                    selectionFocusAuto = true;
                }
                uiHandler.postDelayed(() -> {
                    boolean ok = false;
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) {
                            cm.setPrimaryClip(ClipData.newPlainText("Teks", out));
                            ok = true;
                        }
                    } catch (Exception ignored) {
                    }
                    toast(ok ? "Teks disalin ke clipboard" : "Gagal menyalin teks");
                    if (selectionFocusAuto) {
                        uiHandler.postDelayed(() -> {
                            if (selectionFocusAuto) {
                                selectionFocusAuto = false;
                                setFocusMode(false);
                            }
                        }, 1800);
                    }
                }, 350);
            });
        }
    }

    // ------------------------------------------------------ responsive sizing

    private void scheduleResponsiveViewport() {
        uiHandler.removeCallbacks(reflowRunnable);
        uiHandler.postDelayed(reflowRunnable, 120);
    }

    private void adaptToolbar() {
        if (toolbar == null || params == null) return;
        int w = params.width;
        if (btnForwardView != null) {
            btnForwardView.setVisibility(w < dp(430) ? View.GONE : View.VISIBLE);
        }
        if (btnReloadView != null) {
            btnReloadView.setVisibility(w < dp(390) ? View.GONE : View.VISIBLE);
        }
    }

    private void applyResponsiveViewport() {
        if (webView == null || params == null || windowHidden) return;
        adaptToolbar();
        float density = getResources().getDisplayMetrics().density;
        if (density <= 0f) density = 1f;
        final int cssWidth = Math.max(1, Math.round(params.width / density));
        int zoom = isHome() ? 100 : getZoomPercent();
        String js = "(function(){try{"
                + "var MINW=" + MIN_LAYOUT_WIDTH_CSS + ",cssW=" + cssWidth
                + ",z=" + (zoom / 100.0) + ",changed=false;"
                + "var head=document.head||document.documentElement;if(!head)return;"
                + "var el=document.documentElement;"
                + "if(el&&el.style&&el.style.zoom){el.style.removeProperty('zoom');changed=true;}"
                + "var m=document.querySelector('meta[name=\"viewport\"]');"
                + "var cur=m?(m.getAttribute('content')||''):'';"
                + "var orig=window.__fbOver?window.__fbOrig:cur;"
                + "var responsive=/width\\s*=\\s*device-width/i.test(orig);"
                + "var need=(cssW<MINW)||!responsive||Math.abs(z-1)>0.001;"
                + "var w=Math.max(Math.round(cssW/z),MINW);var sc=cssW/w;"
                + "if(need){"
                + "if(!window.__fbOver){window.__fbOver=true;window.__fbHad=!!m;window.__fbOrig=cur;}"
                + "if(!m){m=document.createElement('meta');m.setAttribute('name','viewport');head.appendChild(m);}"
                + "var c='width='+w+',initial-scale='+sc.toFixed(4)"
                + "+',minimum-scale=0.1,maximum-scale=10,user-scalable=yes';"
                + "if(m.getAttribute('content')!==c){m.setAttribute('content',c);changed=true;}"
                + "}else if(window.__fbOver){"
                + "if(window.__fbHad&&m){m.setAttribute('content',window.__fbOrig);}"
                + "else if(m&&!window.__fbHad&&m.parentNode){m.parentNode.removeChild(m);}"
                + "window.__fbOver=false;changed=true;}"
                + "var minFs=(16/Math.min(1,Math.max(sc,0.25))).toFixed(1);"
                + "var st=document.getElementById('__fbZoomFix');"
                + "if(!st){st=document.createElement('style');st.id='__fbZoomFix';head.appendChild(st);}"
                + "var fx='input,textarea,select,[contenteditable=\"\"],[contenteditable=\"true\"]"
                + "{font-size:max('+minFs+'px,1em) !important;}';"
                + "if(st.textContent!==fx){st.textContent=fx;changed=true;}"
                + "if(changed){window.dispatchEvent(new Event('resize'));}"
                + "}catch(e){}})();";
        webView.evaluateJavascript(js, null);
    }

    public static String normalizeUrl(String input) {
        if (input == null) input = "";
        input = input.trim();
        if (input.isEmpty()) return "https://www.google.com";
        String lower = input.toLowerCase();
        if (lower.startsWith("http://") || lower.startsWith("https://")
                || lower.startsWith("file://") || lower.startsWith("about:")) {
            return input;
        }
        if (!input.contains(" ") && input.contains(".")) {
            return "https://" + input;
        }
        return "https://www.google.com/search?q=" + Uri.encode(input);
    }

    private void loadUrl(String url) {
        if (webView != null && url != null) {
            webView.loadUrl(url);
        }
    }

    private void clampPositionAndSize() {
        int[] scr = getScreenSize();
        if (params.width > scr[0]) params.width = scr[0];
        if (params.height > scr[1]) params.height = scr[1];
        if (params.x < 0) params.x = 0;
        if (params.y < 0) params.y = 0;
        if (params.x > scr[0] - params.width) params.x = Math.max(0, scr[0] - params.width);
        if (params.y > scr[1] - params.height) params.y = Math.max(0, scr[1] - params.height);
    }

    private int[] getScreenSize() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getCurrentWindowMetrics().getBounds();
            return new int[]{b.width(), b.height()};
        } else {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            return new int[]{dm.widthPixels, dm.heightPixels};
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private boolean canDrawOverlays() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ----------------------------------------------------------- notification

    private void startForegroundCompat() {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification buildNotification() {
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) {
            piFlags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent contentPi = PendingIntent.getActivity(this, 1,
                new Intent(this, MainActivity.class), piFlags);

        PendingIntent closePi = PendingIntent.getService(this, 2,
                new Intent(this, FloatingBrowserService.class).setAction(ACTION_CLOSE), piFlags);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_browser)
                .setContentTitle("Floating Browser aktif")
                .setContentText("Jendela browser melayang sedang berjalan.")
                .setOngoing(true)
                .setContentIntent(contentPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Tutup", closePi);
        if (Build.VERSION.SDK_INT >= 26) {
            b.setColor(Color.parseColor("#3A57E8"));
        }
        return b.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID,
                    "Floating Browser", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Notifikasi saat jendela browser melayang aktif");
            nm.createNotificationChannel(ch);
        }
    }

    // -------------------------------------------------------------- lifecycle

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        uiHandler.removeCallbacks(configRunnable);
        uiHandler.postDelayed(configRunnable, 300);
    }

    @Override
    public void onDestroy() {
        uiHandler.removeCallbacksAndMessages(null);
        if (customView != null) {
            if (customViewCallback != null) {
                try {
                    customViewCallback.onCustomViewHidden();
                } catch (Exception ignored) {
                }
                customViewCallback = null;
            }
            customView = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.removeJavascriptInterface("Android");
            if (timersPaused) {
                webView.resumeTimers();
                timersPaused = false;
            }
        }
        if (rootView != null) {
            try {
                windowManager.removeView(rootView);
            } catch (Exception ignored) {
            }
            rootView = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        retriedHttp.clear();
        sRunning = false;
        super.onDestroy();
    }
}
