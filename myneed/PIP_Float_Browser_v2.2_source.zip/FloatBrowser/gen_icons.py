import struct, zlib, os

def write_png(path, img):
    h = len(img)
    w = len(img[0])
    raw = b''
    for row in img:
        raw += b'\x00' + b''.join(struct.pack('BBBB', *p) for p in row)
    def chunk(typ, data):
        c = struct.pack('>I', len(data)) + typ + data
        c += struct.pack('>I', zlib.crc32(typ + data) & 0xffffffff)
        return c
    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
    png += chunk(b'IDAT', zlib.compress(raw, 9))
    png += chunk(b'IEND', b'')
    with open(path, 'wb') as f:
        f.write(png)

def make(size, path):
    bg = (58, 87, 232, 255)
    wh = (255, 255, 255, 255)
    clear = (0, 0, 0, 0)
    corner = size * 0.22
    c = (size - 1) / 2.0
    Rou = size * 0.31
    Rin = Rou - max(1.0, size * 0.052)
    e_rx = size * 0.155
    e_th = max(1.0, size * 0.045)
    line_h = max(1.0, size * 0.048)
    img = []
    for y in range(size):
        row = []
        for x in range(size):
            dx = max(corner - x, x - (size - 1 - corner), 0.0)
            dy = max(corner - y, y - (size - 1 - corner), 0.0)
            if dx * dx + dy * dy > corner * corner:
                row.append(clear)
                continue
            col = bg
            d = ((x - c) ** 2 + (y - c) ** 2) ** 0.5
            if Rin <= d <= Rou:
                col = wh
            else:
                t = (y - c) / Rou
                if abs(t) <= 1.0:
                    off = e_rx * (1.0 - t * t) ** 0.5
                    if abs(x - (c + off)) <= e_th / 2 or abs(x - (c - off)) <= e_th / 2:
                        col = wh
                if col == bg and abs(y - c) <= line_h / 2 and d <= Rou - e_th * 0.7:
                    col = wh
            row.append(col)
        img.append(row)
    write_png(path, img)

base = '/content/FloatBrowser/app/src/main/res'
sizes = [('mipmap-mdpi', 48), ('mipmap-hdpi', 72), ('mipmap-xhdpi', 96),
         ('mipmap-xxhdpi', 144), ('mipmap-xxxhdpi', 192)]
for folder, s in sizes:
    d = os.path.join(base, folder)
    os.makedirs(d, exist_ok=True)
    make(s, os.path.join(d, 'ic_launcher.png'))
    print('wrote', os.path.join(d, 'ic_launcher.png'))
